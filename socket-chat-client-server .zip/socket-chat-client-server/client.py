import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, messagebox, font

HEADER_LENGTH = 10
IP = "127.0.0.1"
PORT = 1234

class ChatClient:
    def __init__(self, master):
        self.master = master
        self.master.withdraw()  # Hide main window initially

        self.username = None
        self.ask_username()  # Wait until username entered

        # Show main window after username input
        self.master.deiconify()
        self.master.title(f"Chat Client - {self.username}")
        self.master.geometry("600x500")
        self.master.configure(bg="black")  # Black background

        # Setup socket
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.client_socket.connect((IP, PORT))
        except Exception as e:
            messagebox.showerror("Connection Error", f"Could not connect to server: {e}")
            self.master.destroy()
            return

        self.client_socket.setblocking(False)

        # Send username to server
        self.send_message(self.username)

        # Fonts
        self.chat_font = font.Font(family="Helvetica", size=12)
        self.entry_font = font.Font(family="Helvetica", size=11)

        # Create UI elements
        self.chat_area = scrolledtext.ScrolledText(
            self.master, state='disabled', bg="black", fg="white",
            font=self.chat_font, wrap=tk.WORD
        )
        self.chat_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # Configure green text tag
        self.chat_area.tag_config('green_msg', foreground='#27AE60')

        self.entry_frame = tk.Frame(self.master, bg="black")
        self.entry_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

        self.msg_entry = tk.Entry(
            self.entry_frame, font=self.entry_font,
            bg="black", fg="white", insertbackground="white"
        )
        self.msg_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=5, ipady=4)
        self.msg_entry.bind("<Return>", self.send_button_click)

        self.send_button = tk.Button(
            self.entry_frame, text="Send", bg="#27AE60", fg="white",
            font=("Helvetica", 11, "bold"),
            activebackground="#2ECC71", activeforeground="white",
            command=self.send_button_click
        )
        self.send_button.pack(side=tk.LEFT, padx=(10, 5), pady=5, ipadx=10, ipady=4)
        self.send_button.config(cursor="hand2")

        self.clear_button = tk.Button(
            self.entry_frame, text="Clear Chat", bg="#C0392B", fg="white",
            font=("Helvetica", 11, "bold"),
            activebackground="#E74C3C", activeforeground="white",
            command=self.clear_chat
        )
        self.clear_button.pack(side=tk.LEFT, padx=(5, 0), pady=5, ipadx=10, ipady=4)
        self.clear_button.config(cursor="hand2")

        # Start thread to receive messages
        self.running = True
        threading.Thread(target=self.receive_messages, daemon=True).start()

        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)

    def ask_username(self):
        self.username_popup = tk.Toplevel(self.master)
        self.username_popup.title("Enter Username")
        self.username_popup.geometry("300x100")
        self.username_popup.grab_set()  # Make modal
        tk.Label(
            self.username_popup, text="Enter your username:",
            font=("Helvetica", 12)
        ).pack(pady=5)
        self.username_entry = tk.Entry(self.username_popup, font=("Helvetica", 12))
        self.username_entry.pack(pady=5)
        self.username_entry.focus()
        tk.Button(
            self.username_popup, text="OK", font=("Helvetica", 11, "bold"),
            bg="#2980B9", fg="white",
            activebackground="#3498DB", activeforeground="white",
            command=self.set_username
        ).pack(pady=5)
        self.master.wait_window(self.username_popup)

    def set_username(self):
        username = self.username_entry.get().strip()
        if not username:
            messagebox.showwarning("Input error", "Username cannot be empty!")
            return
        self.username = username
        self.username_popup.destroy()

    def send_message(self, message):
        message_bytes = message.encode('utf-8')
        message_header = f"{len(message_bytes):<{HEADER_LENGTH}}".encode('utf-8')
        self.client_socket.send(message_header + message_bytes)

    def send_button_click(self, event=None):
        message = self.msg_entry.get().strip()
        if not message:
            return
        self.send_message(message)

        # Show own message immediately (in green)
        timestamp = self.get_current_time()
        self.append_message(f"[{timestamp}] {self.username} > {message}")

        self.msg_entry.delete(0, tk.END)

    def clear_chat(self):
        self.chat_area.configure(state='normal')
        self.chat_area.delete('1.0', tk.END)
        self.chat_area.configure(state='disabled')

    def receive_messages(self):
        while self.running:
            try:
                message_header = self.client_socket.recv(HEADER_LENGTH)
                if not len(message_header):
                    self.append_message("Disconnected from server")
                    break
                message_length = int(message_header.decode('utf-8').strip())
                message = self.client_socket.recv(message_length).decode('utf-8')
                self.append_message(message)
            except BlockingIOError:
                continue
            except Exception as e:
                self.append_message(f"Error: {e}")
                break

    def append_message(self, message):
        self.chat_area.configure(state='normal')
        self.chat_area.insert(tk.END, message + '\n', 'green_msg')
        self.chat_area.configure(state='disabled')
        self.chat_area.yview(tk.END)

    def get_current_time(self):
        from datetime import datetime
        return datetime.now().strftime('%H:%M')

    def on_closing(self):
        self.running = False
        try:
            self.client_socket.close()
        except:
            pass
        self.master.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatClient(root)
    root.mainloop()
