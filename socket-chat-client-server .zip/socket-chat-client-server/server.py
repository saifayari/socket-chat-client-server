import socket
import select
import datetime

HEADER_LENGTH = 10
IP = "127.0.0.1"
PORT = 1234

# Create and configure server socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((IP, PORT))
server_socket.listen()

# Track connected sockets and clients
socket_list = [server_socket]
clients = {}

# Receive message from a client
def receive_message(client_socket):
    try:
        message_header = client_socket.recv(HEADER_LENGTH)
        if not len(message_header):
            return False

        message_length = int(message_header.decode("utf-8").strip())
        return {"header": message_header, "data": client_socket.recv(message_length)}
    except:
        return False

print(f"🔌 Server started on {IP}:{PORT}... Waiting for connections.")

# Main loop
while True:
    read_sockets, _, exception_sockets = select.select(socket_list, [], socket_list)

    for notified_socket in read_sockets:
        # New connection
        if notified_socket == server_socket:
            client_socket, client_address = server_socket.accept()
            user = receive_message(client_socket)
            if user is False:
                continue

            socket_list.append(client_socket)
            clients[client_socket] = user

            username = user['data'].decode('utf-8')
            print(f"🟢 Accepted new connection from {client_address[0]}:{client_address[1]} username: {username}")

            # Broadcast join message
            join_msg = f"🟢 {username} has joined the chat!".encode('utf-8')
            join_header = f"{len(join_msg):<{HEADER_LENGTH}}".encode('utf-8')
            for client in clients:
                if client != client_socket:
                    client.send(join_header + join_msg)

        # Existing client sending message
        else:
            message = receive_message(notified_socket)

            # Client disconnected
            if message is False:
                username = clients[notified_socket]['data'].decode('utf-8')
                print(f"🔴 {username} has disconnected.")
                socket_list.remove(notified_socket)
                del clients[notified_socket]

                # Broadcast leave message
                leave_msg = f"🔴 {username} has left the chat.".encode('utf-8')
                leave_header = f"{len(leave_msg):<{HEADER_LENGTH}}".encode('utf-8')
                for client in clients:
                    client.send(leave_header + leave_msg)
                continue

            user = clients[notified_socket]
            username = user['data'].decode('utf-8')
            text = message['data'].decode('utf-8')
            timestamp = datetime.datetime.now().strftime('%H:%M')

            print(f"[{timestamp}] {username} > {text}")

            # Format message with timestamp
            display_message = f"[{timestamp}] {username} > {text}".encode('utf-8')
            display_header = f"{len(display_message):<{HEADER_LENGTH}}".encode('utf-8')

            # Broadcast to others
            for client_socket in clients:
                if client_socket != notified_socket:
                    client_socket.send(display_header + display_message)

    # Handle broken sockets
    for notified_socket in exception_sockets:
        socket_list.remove(notified_socket)
        del clients[notified_socket]


